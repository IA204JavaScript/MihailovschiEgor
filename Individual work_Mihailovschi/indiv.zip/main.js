import { menuItems } from './data.js';
import { displayMenu } from './display.js';
import './modal.js';
import './form.js';

// Инициализация
displayMenu(menuItems);